#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

int main(void) {
	const char *server_ip = "127.0.0.1";
	const int server_port = 8877;

	struct sockaddr_in server_address;
	memset(&server_address, 0, sizeof(server_address));
	server_address.sin_family = AF_INET;

	// Convierte la dirección IPv4 de texto a formato binario.
	if (inet_pton(AF_INET, server_ip, &server_address.sin_addr) != 1) {
		fprintf(stderr, "No se pudo convertir la direccion IPv4\n");
		return 1;
	}

	// Convierte el puerto (16 bits) del orden de bytes del equipo al de red.
	server_address.sin_port = htons(server_port);

	// Crea un socket TCP.
	int sock;
	if ((sock = socket(PF_INET, SOCK_STREAM, 0)) < 0) {
		printf("Error en creacion de socket\n");
		return 1;
	}

	// Establece la conexión TCP antes de intercambiar datos.
	if (connect(sock, (struct sockaddr *)&server_address,
	            sizeof(server_address)) < 0) {
		printf("Error en conexion a servidor\n");
		return 1;
	}

	// Mensaje que se enviará al servidor.
	const char *data_to_send = "Hola, RPI via TCP";
	send(sock, data_to_send, strlen(data_to_send), 0);

	int n = 0;
	int len = 0, maxlen = 100;
	char buffer[maxlen];
	char *pbuffer = buffer;

	// Recibe datos hasta el cierre remoto, un error o el agotamiento del búfer.
	while ((n = recv(sock, pbuffer, maxlen, 0)) > 0) {
		pbuffer += n;
		maxlen -= n;
		len += n;

		buffer[len] = '\0';
		printf("Recibido: '%s'\n", buffer);
	}

	// Cierra el socket.
	close(sock);
	return 0;
}
