#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

/*
 * Este servidor utiliza un socket de escucha para aceptar conexiones.
 * accept() devuelve un socket conectado para intercambiar datos con el cliente.
 */

int main(void) {
	// Puerto local del servidor.
	int SERVER_PORT = 8877;

	// Dirección local del servidor.
	struct sockaddr_in server_address;
	memset(&server_address, 0, sizeof(server_address));
	server_address.sin_family = AF_INET;

	// Convierte el puerto (16 bits) del orden de bytes del equipo al de red.
	server_address.sin_port = htons(SERVER_PORT);

	// Convierte el valor IPv4 (32 bits) al orden de bytes de red.
	// INADDR_ANY permite recibir tráfico en cualquier dirección IPv4 local.
	server_address.sin_addr.s_addr = htonl(INADDR_ANY);

	// Crea un socket TCP; socket() devuelve -1 si falla.
	int listen_sock;
	if ((listen_sock = socket(PF_INET, SOCK_STREAM, 0)) < 0) {
		printf("Error en creacion de socket de escucha\n");
		return 1;
	}

	// Asocia el socket a la dirección y al puerto locales; devuelve -1 si falla.
	if ((bind(listen_sock, (struct sockaddr *)&server_address,
	          sizeof(server_address))) < 0) {
		printf("Error en bind\n");
		return 1;
	}

	// Límite solicitado para la cola de conexiones pendientes de aceptación.
	int wait_size = 16;
	if (listen(listen_sock, wait_size) < 0) {
		printf("Error en listen\n");
		return 1;
	}

	// Almacena la dirección del cliente.
	struct sockaddr_in client_address;

	// Atiende clientes de forma indefinida.
	while (true) {
		socklen_t client_address_len = sizeof(client_address);

		// Acepta una conexión y obtiene el socket conectado.
		int sock;
		if ((sock = accept(listen_sock, (struct sockaddr *)&client_address,
		                   &client_address_len)) < 0) {
			printf("Error en apertura de socket\n");
			return 1;
		}

		int n = 0;
		int len = 0, maxlen = 100;
		char buffer[maxlen];
		char *pbuffer = buffer;

		printf("Cliente conectado con IP:  %s\n",
		       inet_ntoa(client_address.sin_addr));

		// Recibe datos hasta el cierre remoto, un error o el agotamiento del búfer.
		while ((n = recv(sock, pbuffer, maxlen, 0)) > 0) {
			pbuffer += n;
			maxlen -= n;
			len += n;

			printf("Recibido: '%s'\n", buffer);

			// Devuelve al cliente el contenido acumulado (eco).
			send(sock, buffer, len, 0);
		}

		close(sock);
	}

	close(listen_sock);
	return 0;
}
