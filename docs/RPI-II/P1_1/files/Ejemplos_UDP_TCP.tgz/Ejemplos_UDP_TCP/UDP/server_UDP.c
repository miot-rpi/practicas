#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

int main(void) {
	// Puerto local del servidor.
	int SERVER_PORT = 8877;

	// Dirección local del servidor.
	struct sockaddr_in server_address;
	memset(&server_address, 0, sizeof(server_address));
	server_address.sin_family = AF_INET;

	// Convierte el puerto (16 bits) del orden de bytes del equipo al de red.
	server_address.sin_port = htons(SERVER_PORT);

	// Convierte el valor IPv4 (32 bits) al orden de bytes de red.
	// INADDR_ANY permite recibir tráfico en cualquier dirección IPv4 local.
	server_address.sin_addr.s_addr = htonl(INADDR_ANY);

	// Crea un socket UDP; socket() devuelve -1 si falla.
	int sock;
	if ((sock = socket(PF_INET, SOCK_DGRAM, 0)) < 0) {
		printf("Error en creacion de socket\n");
		return 1;
	}

	// Asocia el socket a la dirección y al puerto locales; devuelve -1 si falla.
	if ((bind(sock, (struct sockaddr *)&server_address,
	          sizeof(server_address))) < 0) {
		printf("Error en bind\n");
		return 1;
	}

	// Almacena la dirección del cliente.
	struct sockaddr_in client_address;

	// Atiende clientes de forma indefinida.
	while (true) {
		socklen_t client_address_len = sizeof(client_address);
		char buffer[500];

		// Recibe un datagrama y obtiene la dirección del remitente.
		int len = recvfrom(sock, buffer, sizeof(buffer), 0,
		                   (struct sockaddr *)&client_address,
		                   &client_address_len);

		buffer[len] = '\0';

		// inet_ntoa() convierte la dirección IPv4 a texto para mostrarla.
		printf("Recibido: '%s' desde el cliente %s\n", buffer,
		       inet_ntoa(client_address.sin_addr));

		// Devuelve el datagrama recibido al cliente (eco).
		sendto(sock, buffer, len, 0, (struct sockaddr *)&client_address,
		       sizeof(client_address));
	}

	return 0;
}
