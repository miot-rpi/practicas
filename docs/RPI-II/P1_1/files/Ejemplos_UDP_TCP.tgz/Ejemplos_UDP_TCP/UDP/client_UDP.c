#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

int main(void) {
	const char *server_ip = "127.0.0.1";
	const int server_port = 8877;

	struct sockaddr_in server_address;
	memset(&server_address, 0, sizeof(server_address));
	server_address.sin_family = AF_INET;

	// Convierte la dirección IPv4 de texto a formato binario.
	if (inet_pton(AF_INET, server_ip, &server_address.sin_addr) != 1) {
		fprintf(stderr, "No se pudo convertir la direccion IPv4\n");
		return 1;
	}

	// Convierte el puerto (16 bits) del orden de bytes del equipo al de red.
	server_address.sin_port = htons(server_port);

	// Crea un socket UDP.
	int sock;
	if ((sock = socket(PF_INET, SOCK_DGRAM, 0)) < 0) {
		printf("Error en creacion de socket\n");
		return 1;
	}

	// Mensaje que se enviará al servidor.
	const char *data_to_send = "Hola RPI via UDP";

	// Envía el mensaje al servidor.
	int len = sendto(sock, data_to_send, strlen(data_to_send), 0,
	                 (struct sockaddr *)&server_address, sizeof(server_address));

	// Recibe la respuesta de eco del servidor.
	char buffer[100];
	recvfrom(sock, buffer, len, 0, NULL, NULL);

	buffer[len] = '\0';
	printf("Recibido: '%s'\n", buffer);

	// Cierra el socket.
	close(sock);
	return 0;
}
